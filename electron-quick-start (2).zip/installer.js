//installer.js
var createInstaller = require('electron-installer-squirrel-windows');

createInstaller ({
    name: 'electron-quick-start',
    path: './dist/electron-quick-start-win32-x64',
    out: './dist/installer',
    authors: 'lazy_bird',
    exe: 'electron-quick-start.exe',
    appDirectory: './dist/electron-quick-start-win32-x64',
    overwrite: true,
    setup_icon: 'favicon.ico'
}, function done (e) {
    console.log('build success !!');
});